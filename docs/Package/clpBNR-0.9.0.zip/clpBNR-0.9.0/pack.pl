name(clpBNR).
title('CLP over Reals using Interval Arithmetic - includes Rational, Integer and Boolean domains as subsets.').
version('0.9.0').
author('Rick Workman', 'ridgeworks@mac.com').
home('https://github.com/ridgeworks/clpBNR_pl').
