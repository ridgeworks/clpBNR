name(clpBNR).
title('CLP over Reals using Interval Arithmetic - includes Integer and Boolean domains as subsets.').
version('0.7.3').
author('Rick Workman', 'ridgeworks@mac.com').
home('https://github.com/ridgeworks/clpBNR_pl').
